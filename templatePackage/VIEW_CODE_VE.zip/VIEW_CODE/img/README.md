# The Primo New UI Customization Workflow Development Environment


##images documentation

 - Primo allows the customization of the following images;
    1. Library Logo - just place a file named `library-logo.png` in this location
    2. Library favicon - just place a file named `favicon.ico` in this location
    3. Default Resource Types - just place a files following this convention :
        `icon_<resource_type>.png`

        For Example:
        `icon_book.png`







